/*
 * GraphUp (iconoir-icons/GraphUp@0.0.11)
 *
 * Learn More: https://www.framer.com/asset-urls
 */

export * from "/_f/modules/qg9kJNxJ11mlhTs9Gw4y/XAOCFWPhH1xQY73yTWHO/GraphUp.js"
export { default } from "/_f/modules/qg9kJNxJ11mlhTs9Gw4y/XAOCFWPhH1xQY73yTWHO/GraphUp.js"
