/*
 * Link (iconoir-icons/Link@0.0.11)
 *
 * Learn More: https://www.framer.com/asset-urls
 */

export * from "/_f/modules/JONJcJqwUVPGrvrTMH9y/EQlRq8Nh3A28qZZkFe9q/Link.js"
export { default } from "/_f/modules/JONJcJqwUVPGrvrTMH9y/EQlRq8Nh3A28qZZkFe9q/Link.js"
